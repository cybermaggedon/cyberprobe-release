
local observer = {}

observer.event = function(e)
end

return observer

